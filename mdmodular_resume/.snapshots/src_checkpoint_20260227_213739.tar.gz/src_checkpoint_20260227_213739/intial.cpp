#include <iostream>
#include <random>
#include <cmath>
#include <vector>

#include "3.h"



// ----------------------------
// random (first molecular)
std::mt19937 global_eng(std::random_device{}());

void IntialData(Data &data, parameter1 &pr1)
{   
    //double m = pr1.mb0;
    double T = pr1.TT;
    double kb = pr1.kb;
    double sigamaW =  pr1.s0 * std::sqrt(T * kb * pr1.mw); // maxwell-boltzmann(W)
    double sigamaBe = pr1.s0 * std::sqrt(T * kb * pr1.mb); // maxwell-boltzmann(Be)
    if (sigamaW == 0.0 || sigamaBe == 0.0)
    {
        cerr << "[RandomV0] sigma is zero (kb=" << kb << ", T=" << T << ", mW=" << pr1.mw << ", mBe=" << pr1.mb
             << "), velocities will stay 0. Check parameter.pr1.\n";
    }
    normal_distribution<double> gaussW(0.0, sigamaW);//gauss(average, sigma)
    normal_distribution<double> gaussBe(0.0, sigamaBe);//gauss(average, sigma)

    for (int i = 0; i < data.n; i++)
    {
        Atom &a = data.atoms[i];
        if (a.atom_type == ATOM_TYPE_OTHER)
            a.atom_type = AtomTypeFromName(a.name);

        if (a.atom_type == ATOM_TYPE_W)
        {
            a.p.a00 = gaussW(global_eng);
            a.p.a10 = gaussW(global_eng);
            a.p.a20 = gaussW(global_eng);
        }
        else if (a.atom_type == ATOM_TYPE_BE)
        {
            a.p.a00 = gaussBe(global_eng);
            a.p.a10 = gaussBe(global_eng);
            a.p.a20 = gaussBe(global_eng);
        }
       
    }

    //p_cm = 0
    Matrix31 p_cm(0.0, 0.0, 0.0);

    for (int i = 0; i < data.n; i++)
    {
        p_cm = data.atoms[i].p + p_cm;
    }
    //
    p_cm.a00 /= data.n;
    p_cm.a10 /= data.n;
    p_cm.a20 /= data.n;

    //
    for (int i = 0; i < data.n; i++)
    {
        data.atoms[i].p = data.atoms[i].p - p_cm;
    }


    pr1.g = 3 * data.n - 3;

    //pr1.g = 3 * data.n;
    data.s0 = pr1.s0;
    data.ps0 = pr1.ps0;
    pr1.T = pr1.TT;
}
// ----------------------------
